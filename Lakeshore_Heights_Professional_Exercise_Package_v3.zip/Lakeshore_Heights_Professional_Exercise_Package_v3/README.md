# Lakeshore Heights Tower — Professional Exercise Package v3
Companion download for *Practical Learning of Microsoft Project* (Sharifi Publishing, First Edition 2026).

Every file runs on the book's single case study: Lakeshore Heights Tower — a fictional $145M, 25-storey
condominium in Mississauga, Ontario, from Notice to Proceed (2026-09-08) through Substantial Performance.

## What's inside

| Folder | Contents | Book chapters |
|---|---|---|
| 01_Microsoft_Project_XML | 12 exercises x 2 (PRACTICE_START + COMPLETED) = 24 importable schedules, ~146 activities | Ch. 10-60 |
| 02_PDF_Schedule_Exports | 6 worked report exports (baseline, tracking Gantt, update, look-ahead, variance, at-risk) | Ch. 49-52 |
| 03_Excel_Workbooks | Master support workbook + 10 standalone tools (DCMA 14-Point, EVM, TIA, Cash Flow S-Curve, Schedule Comparison, SOV Map, Risk Register, Delay Log, Look-Ahead Planner, Progress Tracker) | Ch. 27-49 |
| 04_Templates_CSV | 12 import-ready CSV templates incl. Ontario stat holidays 2026-2029 for calendar setup | Ch. 11, 13, 37-49 |
| 05_Word_Templates | 14 professional document templates: weekly/monthly reports, notices, TIA narrative, recovery memo, sign-offs, closeout | Ch. 33-60 |
| 06_Sample_Reports | 2 fully worked narrative reports (weekly update, owner report) | Ch. 37, 50 |
| 07_Quick_Reference | Keyboard shortcut cheat sheet (Figure 9.4 one-page download) | Ch. 9 |
| 08_ReadMe_and_File_Index | This README, full file index (CSV), machine-readable manifest (JSON) | — |

## Opening the schedule files
Microsoft Project 2016 or later: File > Open > select the .xml > "As a new project."
Open the PRACTICE_START file for the exercise; the COMPLETED file is the answer key.

## Conventions
Blue cells = your inputs (yellow = the key ones). Black = calculated - do not type over.
Gray italic rows in Word templates are worked examples - delete before issuing.
Delay event DE-029 (the book's six-week envelope delay, month 17) threads through the delay log,
TIA worksheet, notice letter, and exercises 10-11 - the same event everywhere, on purpose.

## Licence
For use by owners of the book on their own projects and training. Redistribution of the package
itself is not permitted. Templates are general practice aids, not legal or contractual advice.

(c) 2026 Ahmad Sharifi / Sharifi Publishing - sharifipublishing.com
